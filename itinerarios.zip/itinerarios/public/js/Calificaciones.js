$(document).ready(function(){

$( "#formCalificar" ).submit(function( event ) {
 var parametros = $(this).serialize();
 var token = $("#token").val();
 alert("as");
	 $.ajax({
			type: "POST",
			header:{'X-CSRF-TOKEN': token},
			url: "http://localhost:8001/Calificaciones",
			dataType: 'json',
			data: {parametros:parametros}
	});
});

});