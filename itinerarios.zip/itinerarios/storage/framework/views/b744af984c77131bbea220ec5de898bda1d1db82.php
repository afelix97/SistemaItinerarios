<?php $__env->startSection('title','EmpleadosWS'); ?>

<?php $__env->startSection('content'); ?>
	<main class="py-4 ">
       <div class="container">
  <div class="row justify-content-center">
    <div class="col-md-12 ">
      <div class="card box-shadow ">
        <div class="card-header" style="font-size: large;"><strong>Empleados Web Service</strong>
         
               <!-- <a href="" class="btn btn-outline-secondary btn-sm float-right">Volver</a> -->

        </div>

        <div class="card-body ">   
      <div class="row">
        <div class="col-md-4">
           <select class="form-control" name="Empleado" id="Empleado" required="">
             <option value="">Selecciona Un Empleado</option>  
          <?php $__currentLoopData = $Empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($Empleado->id); ?>"><?php echo e($Empleado->nombre); ?></option>   
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
      </div>
<br><br><br><br><br><br><br><br><br>
          
        </div> 
      </div> 
    </div> 
  </div> 
</div> 
        </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>