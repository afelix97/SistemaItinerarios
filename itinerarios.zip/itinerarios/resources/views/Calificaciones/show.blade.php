@extends('layouts.app')


@section('title','Calificacion')

@section('content')
 <main class="py-4">
       <div class="container">
  <div class="row justify-content-center">
    <div class="col-md-10">
      <div class="card box-shadow">
        <div class="card-header" style="font-size: large;"><strong>Calificaciones </strong>
         
                <a href="../Actividades/" class="btn btn-outline-secondary btn-sm float-right">Volver</a>

        </div>

        <div class="card-body">   
                <div class="row">
                    <div class="col-md-6">
                        <!--<h3>Datos Itinerario-Departamento</h3>-->
                     
                            <p><strong>Itinerario: </strong> 5654</p>
                            <p><strong>Asunto: </strong> Entrenamiento para personal Afore</p>
                            <p><strong>Empleado: </strong> 95739698 - Juan Pérez</p>
                            <p><strong>Departamento: </strong> </p>
                            <p><strong>Centro: </strong> 252590 </p>
                            <p><strong>Autor: </strong> 95739522 - Laura García</p>
                            <p><strong>Inicio: </strong> 29/08/2018</p>
                            <p><strong>Fin: </strong> 15/09/2018</p>
                    
            
                        
                    </div> 
                        @foreach($Calific as $datos)
                    <div class="col-md-6">
                      <h5 class="d-flex justify-content-between align-items-center mb-3">
                        <span class="text-muted">Calificaciones</span>
                        <span class="badge badge-secondary badge-pill">Promedio
                          {{
                            (($datos->disciplina+
                            $datos->responsabilidad+
                            $datos->iniciativa+
                            $datos->sociabilidad+
                            $datos->puntualidad+
                            $datos->Imagenlimpieza)/6)
                          }}
                        </span>
                      </h5>
                      <ul class="list-group mb-3">
                        <li class="list-group-item d-flex justify-content-between">
                          <h6 class="my-0">Disciplina</h6>
                          <strong>{{$datos->disciplina}}</strong>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                           <h6 class="my-0">Responsabilidad</h6>
                          <strong>{{$datos->responsabilidad}}</strong>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                          <h6 class="my-0">Iniciativa</h6>
                          <strong>{{$datos->iniciativa}}</strong>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                          <h6 class="my-0">Saciabilidad</h6>
                          <strong>{{$datos->sociabilidad}}</strong>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                          <h6 class="my-0">Puntualidad</h6>
                          <strong>{{$datos->puntualidad}}</strong>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                          <h6 class="my-0">Imagen y limpieza</h6>
                          <strong>{{$datos->Imagenlimpieza}}</strong>
                        </li>
                      </ul>
                        
                        
                    </div> 
                    @endforeach      
                </div>   
        </div> 
      </div> 
    </div> 
  </div> 
</div> 
        </main>
@endsection