<?php $__env->startSection('title','Calificar'); ?>

<?php $__env->startSection('content'); ?>


 <main class="py-4">
       <div class="container">
  <div class="row justify-content-center">
    <div class="col-md-12">
      <div class="card box-shadow">
        <div class="card-header" style="font-size: large;"><strong>Calificar desempeño</strong>
         
                <a href="../Actividades/" class="btn btn-outline-secondary btn-sm float-right">Volver</a>

        </div>

        <div class="card-body">   

           <form method="POST" action="/Calificaciones" accept-charset="UTF-8" >
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Itinerario: </strong> 1</p>
                        <p><strong>Asunto: </strong> Entrenamiento para personal Afore</p>
                        <p><strong>Empleado: </strong>Jose Plata</p>
                        <p><strong>Departamento: </strong>Ropa</p>
                        <p><strong>Centro: </strong> 54365</p>
                    </div>
                     <div class="col-md-6">
                        <p><strong>Inicio: </strong>05/06/2018</p>
                        <p><strong>Fin: </strong>08/06/2018</p>
                        <p><strong>Autor: </strong>Juan Lopez</p>
                        <p><strong>Estatus: </strong> <a href="">creado-asignado </a></p>
                  </div>
                </div>   

               <hr>


    <h5 align="center">
        <b>Desempeño Departamento </b>
    </h5>

    <div class="form-group">

        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <input type="hidden" name="Departamento" id="Departamento" value="<?php echo e($itinerarios_departamentos); ?>">
                   <label><b>Disciplina:</b></label>
                    <select class="form-control" name="Disciplina" id="Disciplina">
                        <option selected>-Selecciona calificación-</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                    </select>
                </div>

                <div class="form-group">
                   <label><b>Responsabilidad:</b></label>
                    <select class="form-control" name="Responsabilidad" id="Responsabilidad">
                        <option selected>-Selecciona calificación-</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                    </select>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                   <label><b>Iniciativa:</b></label>
                    <select class="form-control" name="Iniciativa" id="Iniciativa">
                        <option selected>-Selecciona calificación-</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                    </select>
                </div>
                <div class="form-group">
                   <label><b>Sociabilidad:</b></label>
                    <select class="form-control" name="Sociabilidad" id="Sociabilidad">
                        <option selected>-Selecciona calificación-</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                    </select>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                   <label><b>Puntualidad:</b></label>
                    <select class="form-control" name="Puntualidad" id="Puntualidad">
                        <option selected>-Selecciona calificación-</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                    </select>
                </div>
                <div class="form-group">
                   <label><b>Imagen y limpieza:</b></label>
                    <select class="form-control" name="Imagenlimpieza" id="Imagenlimpieza">
                        <option selected>-Selecciona calificación-</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                    </select>
                </div>
            </div>
        </div>
    </div>

                <hr>

                <input type="submit"  value="Calificar" class="btn btn-sm btn-outline-secondary float-right">
            </form>
        </div> 
      </div> 
    </div> 
  </div> 
</div> 
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>