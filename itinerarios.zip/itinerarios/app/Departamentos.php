<?php

namespace SCyGEG;

use Illuminate\Database\Eloquent\Model;

class Departamentos extends Model
{
     protected $fillable = ['departamento','descripcion'];
}
