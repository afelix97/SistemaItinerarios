<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Ruta que retorna la vista de bienvenida*/
Route::get('/', function () {
    return view('welcome');
});
Route::get('/itinerario/ActividadesEdit', function () {
    return view('itinerario.editActividades.edit');
});
Route::get('/itinerario/DepartamentosEdit', function () {
    return view('itinerario.editDepartamentos.edit');
});
/*Ruta que manda llamar al controlador de CalificacionesController y ejecuta su metodo create al cual se le pasa un id como parametro*/ 
Route::get('/Calificaciones/create/{id}', 'CalificacionesController@create' );

Route::get('Actividades/EmpleadosWS', 'ActividadesController@EmpleadosWS');
/*Ruta para acceder a los recursos del controlador ActividadesController del cual dependiendo la peticion ejecutara ya sea el metodo index,show, create, store, edit,update, destroy*/ 
Route::resource('Actividades', 'ActividadesController');
/*Ruta para acceder a los recursos del controlador CalificacionesController del cual dependiendo la peticion ejecutara ya sea el metodo index,show, create, store, edit,update, destroy*/ 
Route::resource('Calificaciones', 'CalificacionesController');
/*Ruta para acceder a los recursos del controlador DepartamentosController del cual dependiendo la peticion ejecutara ya sea el metodo index,show, create, store, edit,update, destroy*/ 
Route::resource('Departamentos', 'DepartamentosController');
/*Ruta para acceder a los recursos del controlador itinerariosDepartamentosController del cual dependiendo la peticion ejecutara ya sea el metodo index,show, create, store, edit,update, destroy*/ 
Route::resource('itinerarioDepartamento', 'itinerariosDepartamentosController');
/*Ruta que manda llamar al controlador de itinerarioController y ejecuta su metodo edit al cual se le pasa un id como parametro*/ 
Route::get('/itinerario/edit/{id}', 'itinerarioController@edit' );
/*Ruta para acceder a los recursos del controlador itinerarioController del cual dependiendo la peticion ejecutara ya sea el metodo index,show, edit,update*/ 
Route::resource('itinerario', 'itinerarioController' );



