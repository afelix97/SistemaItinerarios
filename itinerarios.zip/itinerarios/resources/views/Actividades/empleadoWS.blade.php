@extends('layouts.app')


@section('title','EmpleadosWS')

@section('content')
	<main class="py-4 ">
       <div class="container">
  <div class="row justify-content-center">
    <div class="col-md-12 ">
      <div class="card box-shadow ">
        <div class="card-header" style="font-size: large;"><strong>Empleados Web Service</strong>
         
               <!-- <a href="" class="btn btn-outline-secondary btn-sm float-right">Volver</a> -->

        </div>

        <div class="card-body ">   
      <div class="row">
        <div class="col-md-4">
           <select class="form-control" name="Empleado" id="Empleado" required="">
             <option value="">Selecciona Un Empleado</option>  
          @foreach($Empleados as $Empleado)
            <option value="{{$Empleado->id}}">{{$Empleado->nombre}}</option>   
          @endforeach
          </select>
        </div>
      </div>
<br><br><br><br><br><br><br><br><br>
          
        </div> 
      </div> 
    </div> 
  </div> 
</div> 
        </main>
@endsection