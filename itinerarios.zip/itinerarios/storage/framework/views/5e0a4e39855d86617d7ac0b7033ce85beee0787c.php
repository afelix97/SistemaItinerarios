<?php $__env->startSection('title','Itinerarios Departamentos'); ?>

<?php $__env->startSection('content'); ?>
 <main class="py-4 ">
       <div class="container">
  <div class="row justify-content-center">
    <div class="col-md-12 ">
      <div class="card box-shadow ">
        <div class="card-header" style="font-size: large;"><strong>Itinerarios y Departamentos Sin Calificar</strong>
               <!-- <a href="" class="btn btn-outline-secondary btn-sm float-right">Volver</a> -->
        </div>

        <div class="card-body ">   

          <div class="ScrollTabla" style="height: 200px;">
<table class="table table-hover border ">
  <thead>
    <tr>
      <th>#</th>
      <th>itinerario_id</th>
      <th >Departamento_id</th>
      <th >Centro</th>
      <th>Estatus_id</th>
      <th>Empleado_id</th>
       <th class="Ajust">Acciones</th>
    </tr>
  </thead>
  <tbody >
    <?php $__currentLoopData = $itinerariosDep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
      <td><?php echo e($datos->id); ?></td>
      <th scope="row"><?php echo e($datos->itinerario_id); ?></th>
      <td><?php echo e($datos->departamento); ?></td>
      <td><?php echo e($datos->centro); ?></td>
      <td>Sin Calificar</td>
      <td>2</td>
      <td>
           <a href="/Calificaciones/create/<?php echo e($datos->id); ?>" class="btn btn-outline-secondary btn-sm">Calificar</a> 
          
      </td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>
        </div> 
      </div> 
    </div> 
  </div> 
</div> 
        </main>
        <main class="py-4 ">
       <div class="container">
  <div class="row justify-content-center">
    <div class="col-md-12 ">
      <div class="card box-shadow ">
        <div class="card-header" style="font-size: large;"><strong>Itinerarios y Departamentos Calificados</strong>
               <!-- <a href="" class="btn btn-outline-secondary btn-sm float-right">Volver</a> -->
        </div>

        <div class="card-body ">   

          <div class="ScrollTabla" style="height: 200px;">
<table class="table table-hover border ">
  <thead>
     <tr>
      <th>#</th>
      <th>itinerario_id</th>
      <th >Departamento_id</th>
      <th >Centro</th>
      <th>Estatus_id</th>
      <th>Empleado_id</th>
       <th class="Ajust">Acciones</th>
    </tr>
  </thead>
  <tbody >
  <?php $__currentLoopData = $itinerariosDepCalif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datoscalif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
      <td><?php echo e($datoscalif->id); ?></td>
      <th scope="row">2</th>
      <td><?php echo e($datoscalif->departamento); ?></td>
      <td>54365</td>
      <td>Calificado</td>
      <td>3</td>
      <td>
          <a href="/Calificaciones/<?php echo e($datoscalif->id); ?>" class="btn btn-outline-secondary btn-sm">Ver</a> 
          
      </td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>
        </div> 
      </div> 
    </div> 
  </div> 
</div> 
        </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>