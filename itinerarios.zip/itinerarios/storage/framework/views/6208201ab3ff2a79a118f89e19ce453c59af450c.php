<?php $__env->startSection('title','Select Departamentos'); ?>

<?php $__env->startSection('content'); ?>
<main class="py-4">
       <div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8 col-lg-10">
      <div class="card box-shadow">
        <div class="card-header" style="font-size: large;"><strong>Editar Departamentos Seleccionados</strong>
         
                <a href="" class="btn btn-outline-secondary btn-sm float-right">Volver</a>

        </div>

        <div class="card-body">   

            <form method="POST" action="" accept-charset="UTF-8" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Itinerario: </strong>2</p>
                        <p><strong>Asunto: </strong> Entrenamiento para personal Afore</p>
                        <p><strong>Empleado: </strong>Juan Pérez</p>
                    </div>
                     <div class="col-md-6">
                        <p><strong>Autor: </strong>Laura García</p>
                        <p><strong>Estatus: </strong> <a href="">creado-asignado </a></p>
                  </div>
                </div>   

               <hr>


                <h5>Lista Departamentos Asignados</h5>
                <div class="form-group">
                    <ul class="list-unstyled">
                            <div class="row">
                                
                        <div class="col-md-6">
                            <li>
                                <label>
                                    <input type="checkbox" checked=""> <b>Ropa. </b>
                                    <em>Sin descripción</em>
                                </label>
                            </li>
                        </div>
                        <div class="col-md-6">
                            <li>
                                <label>
                                    <input type="checkbox" checked=""><b> Muebles.</b>
                                    <em>Sin descripción</em>
                                </label>
                            </li>
                        </div>
                        <div class="col-md-6">
                            <li>
                                <label>
                                    <input type="checkbox" checked=""> <b>Cajas. </b>
                                    <em>Sin descripción</em>
                                </label>
                            </li>
                        </div>
                        <div class="col-md-6">
                            <li>
                                <label>
                                    <input type="checkbox" checked=""><b> Banco. </b>
                                    <em>Sin descripción</em>
                                </label>
                            </li>
                        </div>
                     
                            </div>
                    </ul>
                </div>
            </form>
        </div> 
         <div class="card-footer">   

            <form method="POST" action="" accept-charset="UTF-8" enctype="multipart/form-data">
                
                <h5>Lista Departamentos Sin Asignar</h5>
                <div class="form-group">
                    <ul class="list-unstyled">
                            <div class="row">
                                
                           
                         <div class="col-md-6">
                              <li>
                                    <label>
                                        <input type="checkbox"> <b>CAT. </b>
                                        <em>Sin descripción</em>
                                    </label>
                                </li>   
                        </div>
                         <div class="col-md-6">
                            <li>
                                <label>
                                    <input type="checkbox"> <b>Bodega. </b>
                                    <em>Sin descripción</em>
                                </label>
                            </li>
                        </div>
                         <div class="col-md-6">  
                            <li>
                                <label>
                                    <input type="checkbox"><b> Cobranza. </b>
                                    <em>Sin descripción</em>
                                </label>
                            </li>
                        </div>
                        <div class="col-md-6">
                            <li>
                                <label>
                                    <input type="checkbox"> <b>Óptica. </b>
                                    <em>Sin descripción</em>
                                </label>
                            </li>
                        </div>
                    </ul>
                </div>
    

                <hr>

                <input type="submit"  value="Finalizar" class="btn btn-sm btn-outline-secondary float-right">
            </form>
        </div> 
      </div> 
    </div> 
  </div> 
</div> 
        </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>