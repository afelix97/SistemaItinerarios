@extends('layouts.app')


@section('title','Itinerarios Departamentos')

@section('content')
 <main class="py-4 ">
       <div class="container">
  <div class="row justify-content-center">
    <div class="col-md-12 ">
      <div class="card box-shadow ">
        <div class="card-header" style="font-size: large;"><strong>Itinerarios y Departamentos Sin Calificar</strong>
               <!-- <a href="" class="btn btn-outline-secondary btn-sm float-right">Volver</a> -->
        </div>

        <div class="card-body ">   

          <div class="ScrollTabla" style="height: 200px;">
<table class="table table-hover border ">
  <thead>
    <tr>
      <th>#</th>
      <th>itinerario_id</th>
      <th >Departamento_id</th>
      <th >Centro</th>
      <th>Estatus_id</th>
      <th>Empleado_id</th>
       <th class="Ajust">Acciones</th>
    </tr>
  </thead>
  <tbody >
    @foreach($itinerariosDep as $datos)

    <tr>
      <td>{{$datos->id}}</td>
      <th scope="row">{{$datos->itinerario_id}}</th>
      <td>{{$datos->departamento}}</td>
      <td>{{$datos->centro}}</td>
      <td>Sin Calificar</td>
      <td>2</td>
      <td>
           <a href="/Calificaciones/create/{{$datos->id}}" class="btn btn-outline-secondary btn-sm">Calificar</a> 
          
      </td>
    </tr>
   @endforeach
  </tbody>
</table>
</div>
        </div> 
      </div> 
    </div> 
  </div> 
</div> 
        </main>
        <main class="py-4 ">
       <div class="container">
  <div class="row justify-content-center">
    <div class="col-md-12 ">
      <div class="card box-shadow ">
        <div class="card-header" style="font-size: large;"><strong>Itinerarios y Departamentos Calificados</strong>
               <!-- <a href="" class="btn btn-outline-secondary btn-sm float-right">Volver</a> -->
        </div>

        <div class="card-body ">   

          <div class="ScrollTabla" style="height: 200px;">
<table class="table table-hover border ">
  <thead>
     <tr>
      <th>#</th>
      <th>itinerario_id</th>
      <th >Departamento_id</th>
      <th >Centro</th>
      <th>Estatus_id</th>
      <th>Empleado_id</th>
       <th class="Ajust">Acciones</th>
    </tr>
  </thead>
  <tbody >
  @foreach($itinerariosDepCalif as $datoscalif)

    <tr>
      <td>{{$datoscalif->id}}</td>
      <th scope="row">2</th>
      <td>{{$datoscalif->departamento}}</td>
      <td>54365</td>
      <td>Calificado</td>
      <td>3</td>
      <td>
          <a href="/Calificaciones/{{$datoscalif->id}}" class="btn btn-outline-secondary btn-sm">Ver</a> 
          
      </td>
    </tr>
   @endforeach
  </tbody>
</table>
</div>
        </div> 
      </div> 
    </div> 
  </div> 
</div> 
        </main>
@endsection