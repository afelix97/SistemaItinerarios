<?php $__env->startSection('title','Actividad'); ?>

<?php $__env->startSection('content'); ?>
  <div id="app">
        <main class="py-4">
       <div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8 col-lg-10">
      <div class="card box-shadow">
        <div class="card-header" style="font-size: large;"><strong>Departamento</strong>
         
                <a href="../Actividades/" class="btn btn-outline-secondary btn-sm float-right">Volver</a>

        </div>

        <div class="card-body">   

            <form method="POST" action="" accept-charset="UTF-8" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-12">
                        <p><strong>Departamento: </strong> Ropa</p>
                        <p><strong>Descripcion: </strong>Departamento Ropa</p>
                       
                    </div>
                  
                </div>   

               <hr>


               
            </form>
        </div> 
      </div> 
    </div> 
  </div> 
</div> 
        </main>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>