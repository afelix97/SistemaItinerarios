    <!-- en este apartado se indica que esta vista extienda de la vista app, la cual es la vista general a la cual solo se le agregara contenido de los diferentes modulos -->
@extends('layouts.app')

 <!-- Remplazara la yield de la seccion tittle y la remplazara por la que se le especifique en esta vista -->
@section('title','Editar Actividad')

 <!-- Remplazara la yield de la seccion content y la remplazara por la que se le especifique en esta vista -->
@section('content')
  <div id="app">
       
         <main class="py-4">
       <div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8 col-lg-10">
      <div class="card box-shadow">
        <div class="card-header" style="font-size: large;"><strong>Editar Actividad</strong>
         
                <a href="../../Actividades" class="btn btn-outline-secondary btn-sm float-right">Volver</a>

        </div>

        <div class="card-body">                 
            <form method="post" action="/Actividades/{{$Actividad->id}}" accept-charset="UTF-8" enctype="multipart/form-data">
              <!-- se especifica que la forma en el que se hara el envio de datos ser por medio del metodo PUT para que se ejequete en el controlador del metodo de update-->
            	@method('PUT')
              <!-- se protege el formulario con un Token el cual servira contra ataques de no vengan de peticiones laravel -->
            	@csrf
                <div class="form-group">
                    <label for="Actividad">Actividad:</label>
                    <input type="text" name="editActividad" id="editActividad" class="form-control input-sm" placeholder="Capturar nombre de Actividad" required=""  min="0" max="1000" value="{{$Actividad->actividad}}">
                </div>
                <div class="form-group">
                    <label for="descripcion">Descripcion:</label>
                    <textarea name="editdescripcion" id="editdescripcion" class="form-control" placeholder="Capturar Descripcion" required="">{{$Actividad->descripcion}}</textarea>
                </div> 
                  <div class="form-group">
                    <label for="precio">Departamento:</label>
                    <select name="editdepartamento_id" id="editdepartamento_id" class="form-control input-sm" required="">
                        <option value=""  >id Dep2</option>
                        <option value="1">Ropa</option>
                        <option value="2">Muebles</option> 
                    </select>
                </div>
                <hr>
                <input type="submit"  value="Actualizar" class="btn btn-sm btn-outline-secondary float-right">
            </form>
            
        </div> 
      </div> 
    </div> 
  </div> 
</div> 
        </main>
    </div>

@endsection