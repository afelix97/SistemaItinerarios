<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCalificacionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('calificacions', function (Blueprint $table) {
            $table->increments('id');
             $table->integer('disciplina');
            $table->integer('responsabilidad');
            $table->integer('iniciativa');
            $table->integer('sociabilidad');
            $table->integer('puntualidad');
            $table->integer('Imagenlimpieza');
            $table->integer('itinerarioDepartamento_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('calificacions');
    }
}
