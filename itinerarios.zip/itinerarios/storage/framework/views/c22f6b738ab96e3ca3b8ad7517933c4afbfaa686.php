<!DOCTYPE html>
<html lang="ES">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
		<title>SCyGE - <?php echo $__env->yieldContent('title'); ?></title>
		 <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="../../css/app.css" rel="stylesheet"> 
    <link href="../../css/estilos.css" rel="stylesheet"> 
    
    <style>
        .box-shadow { 
            box-shadow: 0 .25rem .75rem rgba(0, 0, 0, .1);
        }
          .Ajust{
         width: 200px;
            
        }
       .ScrollTabla{
    overflow:scroll;
    height:400px; 
    width:100%; 
    text-align: left;
}

    </style>
	</head>

	<body>
         <nav class="navbar navbar-expand-md navbar-dark bg-primary" style="background-color: #472052;">
      <div class="container">
                <a class="navbar-brand" href="">
                   Control Itinerarios
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Itinerarios</a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="">Crear</a>
                                <a class="dropdown-item" href="">Listar</a>
                            </div>
                        </li>
                         <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Actividades</a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('Actividades.create')); ?>">Crear</a>
                                <a class="dropdown-item" href="<?php echo e(route('Actividades.index')); ?>">Listar</a>
                            </div>
                        </li>
                        
                        <li class="nav-item dropdown">
                          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Calificaciones</a>
                          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('Calificaciones.index')); ?>">Listar</a>
                          </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="">Usuarios</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="">Roles</a>
                        </li>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                            <li class="nav-item">
                                <a class="nav-link" href=""> Usuario: </a>
                            </li>
        

                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    Jefe <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href=""
                                      >
                                       Cerrar sesión
                                    </a>

                                    <form id="logout-form" action="" method="POST" style="display: none;">
                                
                                    </form>
                                </div>
                            </li>
                    </ul>
                </div>
            </div>
    </nav>
    <!-- se especifica atra vez del motor de plantillas blade que este apartado sera remplazado por el contenido que se le especifique en las demas vistas que usen esta anotacion -->
		<?php echo $__env->yieldContent('content'); ?>
	</body>

    <footer style="height: 50px;" class="footer footer-fixed bg-primary">
        
        <center><p style="margin: auto;">@Copyrigth:<a href="#" style="color: white;">GrupoCoppel.com</a></p></center>
        <script src="../../js/app.js"></script>
        <!-- se referencia a jquery y al javascript de calificaciones los cuales se encuentral en la carpeta public del proyecto laravel -->
         <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
          <script src="<?php echo e(asset('js/Calificaciones.js')); ?>"></script>
        <script src="../../js/bootstrap.js"></script>
    </footer>
	
</html>
