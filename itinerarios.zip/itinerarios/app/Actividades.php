<?php

namespace SCyGEG;

use Illuminate\Database\Eloquent\Model;

class Actividades extends Model
{
    protected $fillable = ['actividad','descripcion','departamento_id'];
}
