<?php

namespace SCyGEG\Http\Controllers;

use Illuminate\Http\Request;

class calandoController extends Controller
{
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       echo "Hola index";
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $calando = new calandos();
        $calando->re
        $calando
        return $request->input('descripcion');
       // return $request->all();
    }

    /**
     * Display the specified resource.
     *
     * @param  \SCyGEG\Actividades  $actividades
     * @return \Illuminate\Http\Response
     */
    public function show(calandos $calandos)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \SCyGEG\Actividades  $actividades
     * @return \Illuminate\Http\Response
     */
    public function edit(calandos $calandos)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \SCyGEG\Actividades  $actividades
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, calandos $calandos)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \SCyGEG\Actividades  $actividades
     * @return \Illuminate\Http\Response
     */
    public function destroy(calandos $calandos)
    {
        //
    }
}
