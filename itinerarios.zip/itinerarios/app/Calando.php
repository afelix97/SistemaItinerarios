<?php

namespace SCyGEG;

use Illuminate\Database\Eloquent\Model;

class Calando extends Model
{
    //
}
