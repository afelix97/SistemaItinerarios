<?php $__env->startSection('title','Calificacion'); ?>

<?php $__env->startSection('content'); ?>
 <main class="py-4">
       <div class="container">
  <div class="row justify-content-center">
    <div class="col-md-10">
      <div class="card box-shadow">
        <div class="card-header" style="font-size: large;"><strong>Calificaciones </strong>
         
                <a href="../Actividades/" class="btn btn-outline-secondary btn-sm float-right">Volver</a>

        </div>

        <div class="card-body">   
                <div class="row">
                    <div class="col-md-6">
                        <!--<h3>Datos Itinerario-Departamento</h3>-->
                     
                            <p><strong>Itinerario: </strong> 5654</p>
                            <p><strong>Asunto: </strong> Entrenamiento para personal Afore</p>
                            <p><strong>Empleado: </strong> 95739698 - Juan Pérez</p>
                            <p><strong>Departamento: </strong> </p>
                            <p><strong>Centro: </strong> 252590 </p>
                            <p><strong>Autor: </strong> 95739522 - Laura García</p>
                            <p><strong>Inicio: </strong> 29/08/2018</p>
                            <p><strong>Fin: </strong> 15/09/2018</p>
                    
            
                        
                    </div> 
                        <?php $__currentLoopData = $Calific; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6">
                      <h5 class="d-flex justify-content-between align-items-center mb-3">
                        <span class="text-muted">Calificaciones</span>
                        <span class="badge badge-secondary badge-pill">Promedio
                          <?php echo e((($datos->disciplina+
                            $datos->responsabilidad+
                            $datos->iniciativa+
                            $datos->sociabilidad+
                            $datos->puntualidad+
                            $datos->Imagenlimpieza)/6)); ?>

                        </span>
                      </h5>
                      <ul class="list-group mb-3">
                        <li class="list-group-item d-flex justify-content-between">
                          <h6 class="my-0">Disciplina</h6>
                          <strong><?php echo e($datos->disciplina); ?></strong>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                           <h6 class="my-0">Responsabilidad</h6>
                          <strong><?php echo e($datos->responsabilidad); ?></strong>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                          <h6 class="my-0">Iniciativa</h6>
                          <strong><?php echo e($datos->iniciativa); ?></strong>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                          <h6 class="my-0">Saciabilidad</h6>
                          <strong><?php echo e($datos->sociabilidad); ?></strong>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                          <h6 class="my-0">Puntualidad</h6>
                          <strong><?php echo e($datos->puntualidad); ?></strong>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                          <h6 class="my-0">Imagen y limpieza</h6>
                          <strong><?php echo e($datos->Imagenlimpieza); ?></strong>
                        </li>
                      </ul>
                        
                        
                    </div> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
                </div>   
        </div> 
      </div> 
    </div> 
  </div> 
</div> 
        </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>