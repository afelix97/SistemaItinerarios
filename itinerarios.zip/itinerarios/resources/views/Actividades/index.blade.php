@extends('layouts.app')


@section('title','Actividades')

@section('content')
 <main class="py-4 ">
       <div class="container">
  <div class="row justify-content-center">
    <div class="col-md-12 ">
      <div class="card box-shadow ">
        <div class="card-header" style="font-size: large;"><strong>Actividades</strong>
         
               <!-- <a href="" class="btn btn-outline-secondary btn-sm float-right">Volver</a> -->

        </div>

        <div class="card-body ">   
          <div class="ScrollTabla">
<table class="table table-hover border ">
  <thead>
    <tr>
      <th>#</th>
      <th >Actividad</th>
      <th >Descripcion</th>
      <th>Departamento</th>
       <th class="Ajust">Acciones</th>
    </tr>
  </thead>
  <tbody >
    @foreach($Actividades as $Actividad)

    <tr>
      <th scope="row">{{$Actividad->id}}</th>
      <td>{{$Actividad->actividad}}</td>
      <td>{{$Actividad->descripcion}}</td>
      <td>{{$Actividad->departamento_id}}</td>
      <td>
          <a href="/Actividades/{{$Actividad->id}}" class="btn btn-outline-secondary btn-sm">ver</a> 
          <a href="/Actividades/{{$Actividad->id}}/edit" class="btn btn-outline-secondary btn-sm ">editar</a> 
          
      </td>
    </tr>
   @endforeach
  </tbody>
</table>
</div>
        </div> 
      </div> 
    </div> 
  </div> 
</div> 
        </main>
@endsection