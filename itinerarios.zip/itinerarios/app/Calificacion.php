<?php

namespace SCyGEG;

use Illuminate\Database\Eloquent\Model;

class Calificacion extends Model
{
     protected $fillable = ['disciplina','responsabilidad','iniciativa','sociabilidad','puntualidad','Imagenlimpieza','itinerarioDepartamento_id'];
}
