<?php

namespace SCyGEG\Http\Controllers;

/* se especifica los modelos a usar en este controlador*/
use SCyGEG\Actividades;
use SCyGEG\Departamentos;
/*----------------------------------------------------*/

use Illuminate\Http\Request;

class ActividadesController extends Controller
{
    /**
     * Metodo que retorna la vista de index.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        /* se hace uso del metodo Actividades para mostrar todos los registros que se encuentren en la base de datos*/
        $Actividades= Actividades::all();


           
        /* se retorna la vista actividades index, y se mandan los datos obtenidos del modelo, para poder ser utilizados en la vista*/
      return view('Actividades.index', compact('Actividades'));
    }
    

    /**
     * metodo que muestra la vista create.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       $Departamentos = Departamentos::select('departamentos.id','departamentos.departamento')->get();
        return view('Actividades.create', compact('Departamentos'));
    }

    /**
     * metodo que guarda lo capturado en el formulario de create de actividades.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        /* se hace uso del modelo actividades al cual se le pasan los datos de la nueva actividad*/
        $Actividad = new Actividades();
        $Actividad->actividad = $request->input('Actividad');
        $Actividad->descripcion = $request->input('descripcion');
        $Actividad->departamento_id = $request->input('departamento_id');
        /* metodo que sirve para guarda el nuevo registro en la base de datos  */
        $Actividad->save();
       
       /* una vez concluido todo lo anterior redirige al usuario a la vista index*/
      return redirect()->route('Actividades.index');
    }

    /**
     * metodo que muestra los datos de una actividad en especifica.
     *
     * @param  \SCyGEG\Actividades  $actividades
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
         /* se hace uso del modelo actividades y de ejecuta el metodo find el cual busca todos los datos de ese modelo en la base de datos*/
        $Actividad= Actividades::find($id);
          /* una vez concluido todo lo anterior redirige al usuario a la vista show en la cual se podran apreciar todos los datos de esa actividad*/
        return view('Actividades.show', compact('Actividad'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \SCyGEG\Actividades  $actividades
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
         $Actividad= Actividades::find($id);

        return view('Actividades.edit', compact('Actividad'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \SCyGEG\Actividades  $actividades
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {   
         $Actividad= Actividades::find($id);
         $Actividad->actividad = $request->input('editActividad');
        $Actividad->descripcion = $request->input('editdescripcion');
        $Actividad->departamento_id = $request->input('editdepartamento_id');
        $Actividad->save();

      return redirect()->route('Actividades.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \SCyGEG\Actividades  $actividades
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Actividades::destroy($id);
      return redirect()->route('Actividades.index');
    }
    /**
     * metodo para consumir web service de empleados.
     *
     * @return \Illuminate\Http\Response
     */
    public function EmpleadosWS()
    {
         $cliente = curl_init();
            curl_setopt($cliente, CURLOPT_URL, "http://localhost:8081/SpringREST/cadenas");
            curl_setopt($cliente, CURLOPT_HEADER, 0);
            curl_setopt($cliente, CURLOPT_RETURNTRANSFER, true);

            $datos = curl_exec($cliente);
            curl_close($cliente);

    $Empleados = json_decode($datos);

     return view('Actividades.empleadoWS', compact('Empleados'));
    }
}
