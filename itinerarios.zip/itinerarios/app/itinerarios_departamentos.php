<?php

namespace SCyGEG;

use Illuminate\Database\Eloquent\Model;

class itinerarios_departamentos extends Model
{
    protected $fillable = ['itinerario_id','departamento_id','centro','fecha_inicio','fecha_fin','horario_id','estatus_id'];
}
