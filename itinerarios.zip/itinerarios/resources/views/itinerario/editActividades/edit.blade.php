@extends('layouts.app')


@section('title','Select Actividades')

@section('content')

<main class="py-4">
       <div class="container">
  <div class="row justify-content-center">
    <div class="col-md-12">
      <div class="card box-shadow">
        <div class="card-header" style="font-size: large;"><strong>Asignar Actividades</strong>
         
                <a href="" class="btn btn-outline-secondary btn-sm float-right">Volver</a>

        </div>

        <div class="card-body">   

            <form method="POST" action="" accept-charset="UTF-8" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Itinerario: </strong>1</p>
                        <p><strong>Asunto: </strong> Entrenamiento para personal Afore</p>
                        <p><strong>Empleado: </strong> Juan Pérez</p>
                    </div>
                     <div class="col-md-6">
                        <p><strong>Autor: </strong>Laura García</p>
                        <p><strong>Estatus: </strong> <a href="">creado-asignado </a></p>
                  </div>
                </div>   

               <hr>


    <h5 align="center"><b>Departamento Ropa</b></h5>

    <div class="form-group">
        <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Horario: </b></label>
                    <select class="custom-select" name="estatus" >
                        <option selected>-Selecciona un horario-</option>
                        <option value="Desactivado">Tienda</option>
                        <option value="Activado">Corporativo</option>
                    </select>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">  
                    <label for="fecha_entregar"><b>Fecha inicio: </b></label>
                    <input type="date" name="" class="form-control">
                </div> 
            </div>
            <div class="col-md-3">
                <div class="form-group">  
                    <label for="fecha_entregar"><b>Fecha fin: </b></label>
                    <input type="date" name="" class="form-control">
                </div>    
            </div>
            <div class="col-md-3">
                <div class="form-group">  
                    <label for="fecha_entregar"><b>Centro: </b></label>
                    <select class="custom-select" name="estatus" >
                        <option selected>-Selecciona un horario-</option>
                        <option value="Desactivado">Coppel Humaya</option>
                        <option value="Activado">Coppel Barrancos</option>
                        <option value="Activado">Cobranza La Conquitsa</option>
                        <option value="Activado">Bodega La Primavera</option>
                        <option value="Activado">CAT Andrade</option>
                    </select>
                </div>    
            </div>
        </div>
        
        <ul class="list-unstyled">
                <div class="row border">
                    <div class="col-md-12"><h5>Actividades Asignadas</h5></div>
            <div class="col-md-6">
                <li>
                    <label>
                        <input type="checkbox" checked=""> <b>Plática con el gerente. </b>
                        
                        <em>gerente explica todo al empleado
</em>
                    </label>
                </li>
            </div>
            <div class="col-md-6">
                <li>
                    <label>
                        <input type="checkbox" checked=""> <b>Leer decisiones. </b>
                        <em>leer decision 54545454,54,5,45,4,564,</em>

                        
                    </label>
                </li>
            </div>
            <div class="col-md-6">
                <li>
                    <label>
                        <input type="checkbox" checked=""> <b>Recorrido por áreas. </b>
                        
                         <em>El gerente te da un recorrido por las areas de la tienda</em>
                    </label>
                </li> 
            </div>
            <div class="col-md-6">
                <li>
                    <label>
                        <input type="checkbox" checked=""> <b>Formatos de vendedor. 
                        </b>
                         <em>El gerente de da un formato el cual debes de leer</em>
                    </label>
                </li>
            </div>

        </div>
        <div class="row border">
            <div class="col-md-12"><h5>Actividades Sin Asignar</h5></div>
            <div class="col-md-6">
                <li>
                    <label>
                        <input type="checkbox"> <b>Planos de tienda. </b>
                        
                        <em>El gerente te otorga los planos de la tienda</em>
                    </label>
                </li>   
            </div>
            <div class="col-md-6">
                <li>
                    <label>
                        <input type="checkbox"> <b>Manuales de tienda ropa. </b>
                        
                        <em>el gerente te provee el manual de la tienda ropa</em>
                    </label>
                </li>  
            </div>
            <div class="col-md-6">
                <li>
                    <label>
                        <input type="checkbox"> <b>Cajas ropa. </b>
                        
                         <em>observa el como trabajan las cajeras</em>
                    </label>
                </li>
            </div>
            <div class="col-md-6">
                <li>
                    <label>
                        <input type="checkbox"> <b>Desempeñate como vendedor. </b>
                        
                         <em>Vende a un cliente a lo menos una prenda</em>
                    </label>
                </li>
            </div>
        </div>
        </ul>
    </div>


                <hr>

                <h5 align="center"><b>Departamento Muebles</b></h5>
    <div class="form-group">
        <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Horario: </b></label>
                    <select class="custom-select" name="estatus" >
                        <option selected>-Selecciona un horario-</option>
                        <option value="Desactivado">Tienda</option>
                        <option value="Activado">Corporativo</option>
                    </select>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">  
                    <label for="fecha_entregar"><b>Fecha inicio: </b></label>
                    <input type="date" name="" class="form-control">
                </div> 
            </div>
            <div class="col-md-3">
                <div class="form-group">  
                    <label for="fecha_entregar"><b>Fecha fin: </b></label>
                    <input type="date" name="" class="form-control">
                </div>    
            </div>
            <div class="col-md-3">
                <div class="form-group">  
                    <label for="fecha_entregar"><b>Centro: </b></label>
                    <select class="custom-select" name="estatus" >
                        <option selected>-Selecciona un horario-</option>
                        <option value="Desactivado">Coppel Humaya</option>
                        <option value="Activado">Coppel Barrancos</option>
                        <option value="Activado">Cobranza La Conquitsa</option>
                        <option value="Activado">Bodega La Primavera</option>
                        <option value="Activado">CAT Andrade</option>
                    </select>
                </div>    
            </div>
        </div>
        <ul class="list-unstyled">
                <div class="row">
                    
                <div class="col-md-6">
                
                
                <li>
                    <label>
                        <input type="checkbox"> <b>Plática con el gerente. </b>
                        
                        <em>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia molestiae praesentium tenetur eveniet, et asperiores fuga placeat sed autem doloremque!</em>
                    </label>
                </li>
                <li>
                    <label>
                        <input type="checkbox"> <b>Leer decisiones. </b>
                        <em>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia molestiae praesentium tenetur eveniet, et asperiores fuga placeat sed autem doloremque!</em>

                        
                    </label>
                </li>
                <li>
                    <label>
                        <input type="checkbox"> <b>Recorrido por áreas. </b>
                        
                         <em>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia molestiae praesentium tenetur eveniet, et asperiores fuga placeat sed autem doloremque!</em>
                    </label>
                </li> 
                <li>
                    <label>
                        <input type="checkbox"> <b>Formatos de vendedor. 
                        </b>
                         <em>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia molestiae praesentium tenetur eveniet, et asperiores fuga placeat sed autem doloremque!</em>
                    </label>
                </li>
                </div>
             <div class="col-md-6">
                    
              <li>
                    <label>
                        <input type="checkbox"> <b>Planos de tienda. </b>
                        
                        <em>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia molestiae praesentium tenetur eveniet, et asperiores fuga placeat sed autem doloremque!</em>
                    </label>
                </li>   

                <li>
                    <label>
                        <input type="checkbox"> <b>Bodeguita. </b>
                        
                        <em>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia molestiae praesentium tenetur eveniet, et asperiores fuga placeat sed autem doloremque!</em>
                    </label>
                </li>  
                <li>
                    <label>
                        <input type="checkbox"> <b>Cajas muebles. </b>
                        
                         <em>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia molestiae praesentium tenetur eveniet, et asperiores fuga placeat sed autem doloremque!</em>
                    </label>
                </li>
                
                <li>
                    <label>
                        <input type="checkbox"> <b>Desempeñate como vendedor. </b>
                        
                         <em>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia molestiae praesentium tenetur eveniet, et asperiores fuga placeat sed autem doloremque!</em>
                    </label>
                </li>

        
        
           
                </div>
                </div>
        </ul>
    </div>


                <hr>

                <input type="submit"  value="Guardar" class="btn btn-sm btn-outline-secondary float-right">
            </form>
        </div> 
      </div> 
    </div> 
  </div> 
</div> 
        </main>

@endsection