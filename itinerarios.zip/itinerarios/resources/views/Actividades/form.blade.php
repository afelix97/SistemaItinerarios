<div class="form-group">
	<label for="Actividad">Actividad:</label>
	<input type="text" name="Actividad" id="Actividad" class="form-control input-sm" placeholder="Capturar nombre de Actividad" required=""  min="0" max="1000" value="">
</div>
<div class="form-group">
	<label for="descripcion">Descripcion:</label>
	<textarea name="descripcion" id="descripcion" class="form-control" placeholder="Capturar Descripcion" required=""></textarea>
</div> 
<div class="form-group">
	<label for="precio">Departamento:</label>
	<select name="departamento_id" id="departamento_id" class="form-control input-sm" required="">
	    <option value=""  >id Dep2</option>
	    <option value="1">Ropa</option>
	    <option value="2">Muebles</option> 
	</select>
</div>