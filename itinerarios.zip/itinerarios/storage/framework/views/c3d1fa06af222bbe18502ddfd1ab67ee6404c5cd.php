<?php $__env->startSection('title','Actividades'); ?>

<?php $__env->startSection('content'); ?>
 <main class="py-4 ">
       <div class="container">
  <div class="row justify-content-center">
    <div class="col-md-12 ">
      <div class="card box-shadow ">
        <div class="card-header" style="font-size: large;"><strong>Actividades</strong>
         
               <!-- <a href="" class="btn btn-outline-secondary btn-sm float-right">Volver</a> -->

        </div>

        <div class="card-body ">   
          <div class="ScrollTabla">
<table class="table table-hover border ">
  <thead>
    <tr>
      <th>#</th>
      <th >Actividad</th>
      <th >Descripcion</th>
      <th>Departamento</th>
       <th class="Ajust">Acciones</th>
    </tr>
  </thead>
  <tbody >
    <?php $__currentLoopData = $Actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
      <th scope="row"><?php echo e($Actividad->id); ?></th>
      <td><?php echo e($Actividad->actividad); ?></td>
      <td><?php echo e($Actividad->descripcion); ?></td>
      <td><?php echo e($Actividad->departamento_id); ?></td>
      <td>
          <a href="/Actividades/<?php echo e($Actividad->id); ?>" class="btn btn-outline-secondary btn-sm">ver</a> 
          <a href="/Actividades/<?php echo e($Actividad->id); ?>/edit" class="btn btn-outline-secondary btn-sm ">editar</a> 
          
      </td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>
        </div> 
      </div> 
    </div> 
  </div> 
</div> 
        </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>