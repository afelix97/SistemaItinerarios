@extends('layouts.app')


@section('title','Create')

@section('content')
   
      

        <main class="py-4">
       <div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8 col-lg-10">
      <div class="card box-shadow">
        <div class="card-header" style="font-size: large;"><strong>Crear Actividades</strong>
         
                <a href="../Actividades" class="btn btn-outline-secondary btn-sm float-right">Volver</a>

        </div>

        <div class="card-body">                 
            <form method="POST" action="/Actividades" accept-charset="UTF-8" >
            	@csrf
                <div class="form-group">
                    <label for="Actividad">Actividad:</label>
                    <input  type="text" name="Actividad" id="Actividad" class="form-control input-sm" placeholder="Capturar nombre de Actividad" required="">
                </div>
                <div class="form-group">
                    <label for="descripcion">Descripcion:</label>
                    <textarea name="descripcion" id="descripcion" class="form-control" placeholder="Capturar Descripcion" required=""> </textarea>
                </div>
                  <div class="form-group">
                    <label for="precio">Departamento:</label>
                    <select name="departamento_id" id="departamento_id" class="form-control input-sm" required="">
                         <option value=""  >-Selecciona Departamento-</option>
                    @foreach($Departamentos as $Departamento)
                        <option value="{{$Departamento->id}}">{{$Departamento->departamento}}</option>
                    @endforeach
                    </select>
                </div>
                <hr>
                <input type="submit"  value="Guardar" class="btn btn-sm btn-outline-secondary float-right" >
            </form>
        </div> 
      </div> 
    </div> 
  </div> 
</div> 
        </main>
  

@endsection