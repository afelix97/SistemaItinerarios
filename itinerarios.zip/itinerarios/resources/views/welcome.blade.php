<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet" type="text/css">
          <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="../../css/app.css" rel="stylesheet"> 
    <link href="../../css/estilos.css" rel="stylesheet"> 
        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body class="bg-warning">
        <div class="flex-center position-ref full-height" >
                <div class="top-right links" style="width: 100%;">

                       <img src="{{ asset('img/img6.png') }}" alt="" style="height: 25px; margin-left: 50px;">
                        <a class="btn btn-warning " style="float: right;" href="">Login</a>

                            <a class="btn btn-warning" style="float: right;" href="">Registrar</a>
                       
                </div>
            

            <div class="content">
                <div class="title m-b-md " style=" color: #000080; font-weight: 700; font-style: italic;">
                   
                    Sistema de Control y Gestion de Entrenamiento

                </div>

                <div class="links">
                    <a href="https://laravel.com/docs">Coppel</a>
                    <a href="https://laracasts.com">Bancoppel</a>
                    <a href="https://laravel-news.com">AforeCoppel</a>
                   
                </div>
            </div>
        </div>
    </body>
</html>
