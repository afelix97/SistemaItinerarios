<?php

namespace SCyGEG\Http\Controllers;

use SCyGEG\Calificacion;
use SCyGEG\itinerarios_departamentos;
use SCyGEG\Departamentos;
use Illuminate\Http\Request;
use DB;

class CalificacionesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         //$Calificacion= Calificacion::all();
        $itinerariosDep= DB::table('departamentos')->join('itinerarios_departamentos','departamentos.id','=', 'itinerarios_departamentos.departamento_id')->select('itinerarios_departamentos.id','itinerarios_departamentos.itinerario_id','departamentos.departamento','itinerarios_departamentos.centro','itinerarios_departamentos.estatus_id')->where('itinerarios_departamentos.estatus_id',0)->get();

          $itinerariosDepCalif= DB::table('departamentos')->join('itinerarios_departamentos','departamentos.id','=', 'itinerarios_departamentos.departamento_id')->select('itinerarios_departamentos.id','itinerarios_departamentos.itinerario_id','departamentos.departamento','itinerarios_departamentos.centro','itinerarios_departamentos.estatus_id')->where('itinerarios_departamentos.estatus_id',3)->get();

      return view('Calificaciones.index', compact('itinerariosDep','itinerariosDepCalif'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($id)
    {
        $itinerarios_departamentos=$id;
         return view('Calificaciones.create',compact('itinerarios_departamentos'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $Calificacion = new Calificacion();
        $Calificacion->disciplina = $request->input('Disciplina');
        $Calificacion->responsabilidad = $request->input('Responsabilidad');
        $Calificacion->iniciativa = $request->input('Iniciativa');
         $Calificacion->sociabilidad = $request->input('Sociabilidad');
        $Calificacion->puntualidad = $request->input('Puntualidad');
        $Calificacion->Imagenlimpieza = $request->input('Imagenlimpieza');
        $Calificacion->itinerarioDepartamento_id = $request->input('Departamento');
        $Calificacion->save();

          $ModificarStatusItinDep_A_Calif  =itinerarios_departamentos::find($request->input('Departamento'));
          $ModificarStatusItinDep_A_Calif->estatus_id='3';
          $ModificarStatusItinDep_A_Calif->save();
       
      return redirect()->route('Calificaciones.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
         $Calific= DB::table('calificacions')->where('itinerarioDepartamento_id',$id)->get();

        return view('Calificaciones.show', compact('Calific'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
