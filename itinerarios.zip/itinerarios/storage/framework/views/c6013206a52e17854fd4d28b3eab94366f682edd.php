<?php $__env->startSection('title','Create'); ?>

<?php $__env->startSection('content'); ?>
   
      

        <main class="py-4">
       <div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8 col-lg-10">
      <div class="card box-shadow">
        <div class="card-header" style="font-size: large;"><strong>Crear Actividades</strong>
         
                <a href="../Actividades" class="btn btn-outline-secondary btn-sm float-right">Volver</a>

        </div>

        <div class="card-body">                 
            <form method="POST" action="/Actividades" accept-charset="UTF-8" >
            	<?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="Actividad">Actividad:</label>
                    <input  type="text" name="Actividad" id="Actividad" class="form-control input-sm" placeholder="Capturar nombre de Actividad" required="">
                </div>
                <div class="form-group">
                    <label for="descripcion">Descripcion:</label>
                    <textarea name="descripcion" id="descripcion" class="form-control" placeholder="Capturar Descripcion" required=""> </textarea>
                </div>
                  <div class="form-group">
                    <label for="precio">Departamento:</label>
                    <select name="departamento_id" id="departamento_id" class="form-control input-sm" required="">
                         <option value=""  >-Selecciona Departamento-</option>
                    <?php $__currentLoopData = $Departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Departamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($Departamento->id); ?>"><?php echo e($Departamento->departamento); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <hr>
                <input type="submit"  value="Guardar" class="btn btn-sm btn-outline-secondary float-right" >
            </form>
        </div> 
      </div> 
    </div> 
  </div> 
</div> 
        </main>
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>